from flask import request, redirect, Flask
app = Flask(__name__)
@app.route('flask_redirect')
def flask_redirect():
    '''
    get the url from the request and redirect to it
    '''
    target = request.args.get('target')
    return redirect(target)
